# Getting James live — 4 steps, about 10 minutes

This replaces the n8n/Railway approach entirely. Nothing about your existing n8n workflows or other bots is touched.

## Step 1: Create a free Vercel account
Go to vercel.com → click "Sign Up" → choose "Continue with Email" (or Google/GitHub if you prefer). No payment details needed.

## Step 2: Deploy this folder
Once logged in, on your Vercel dashboard, click "Add New" → "Project". You'll be asked to import a Git repository — instead, look for an option to deploy without Git (sometimes shown as "Deploy" with a folder upload, or you may need to first push this `james-backend` folder to a free GitHub repo and import that). If Vercel only offers Git import on your account, the fastest path is:
1. Go to github.com, sign up free if you don't have an account.
2. Create a new repository, name it `james-backend`.
3. Upload all the files in this folder to that repository (GitHub's web interface lets you drag-and-drop files directly, no command line needed).
4. Back in Vercel, click "Add New" → "Project" → "Import" next to that GitHub repo.
5. Click "Deploy". Leave all settings as default.

## Step 3: Add your Anthropic API key
Before or right after deploying, go to your project's Settings tab in Vercel → "Environment Variables". Add one:
- **Name:** `ANTHROPIC_API_KEY`
- **Value:** paste your Anthropic API key here (use a freshly created one — see note below)

Click Save, then go to the "Deployments" tab and click the three-dot menu on the latest deployment → "Redeploy", so the key takes effect.

**Important:** generate a brand new Anthropic API key for this specifically (console.anthropic.com → Settings → API Keys → Create Key), rather than reusing one that's been shown on screen or in a screenshot before today.

## Step 4: Get your live URL and update the widget
Once deployed, Vercel shows you a URL like `https://james-backend-xyz123.vercel.app`. Your actual API endpoint is that URL plus `/api/james`, for example:
`https://james-backend-xyz123.vercel.app/api/james`

Open `property-assistant-demo.html`, find this line near the top of the script:
```
const BACKEND_URL = "https://YOUR-PROJECT-NAME.vercel.app/api/james";
```
Replace it with your real URL from above. Save the file.

## Test it
Open the HTML file in a browser (double-click works). Have a full conversation — ask about properties, book a viewing, then ask to change the time. It should all work now, including the reschedule case that failed this morning.

## If something doesn't work
Open the browser's dev tools (Cmd+Option+I) → Network tab → try sending a message in the widget → look for a request to your `/api/james` URL → click it → check the Response tab. That will show you the actual error if there is one, rather than guessing.
